CSE-5306 Distributed Systems
Project Assignment 1 Getting Started with Docker
Shivarjun Umesha (1002059222)

Assignment:This assignment aims to provide participants with a thorough understanding of Docker, a pivotal tool in the realm of containerization. Through hands-on projects, we will cover key Docker concepts, from basic architecture and container management to advanced topics like orchestration and security. By the end, participants will gain practical skills to streamline application deployment, enhance collaboration, and optimize performance using Docker. This project is designed to empower individuals to navigate the dynamic landscape of containerization in contemporary software development

The following report contains the command to setup and build container. 

Questions:
1) Follow the get started guide to learn (1) how to build and run an image as a container; (2) how to share images using Docker Hub; (3) how to deploy Docker applications using multiple containers with a database; and (4) how to run applications using Docker Compose.
You should all tasks specified in Part 1 through Part 9 outlined in the guide.
In the report, you should
1.	include all the docker-related commands and briefly explain the purpose of each one of them. 
2.	include the link to your shared image on Docker Hub, as stated in Part 4.
Link: https://hub.docker.com/repository/docker/arjunpawan/getting-started/general

2)Select one programming language and follow their language-specific guides to get yourself familiar with how to containerize an application using Docker. For example,
•	Python: https://docs.docker.com/language/python/Links to an external site.
You should complete three tasks outlined in the guide, i.e., “Build images”, “Run containers”, and “Develop your app”.
You should capture screenshots for every step specified in the guide and included in the report.


